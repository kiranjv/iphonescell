insert into app_settings_items(id, settings_item, value) values (4, "profile downloaded on", "2010-07-27T00:00:00Z");
