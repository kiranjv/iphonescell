ALTER TABLE "profiles" ADD COLUMN "device_key" VARCHAR(250);
